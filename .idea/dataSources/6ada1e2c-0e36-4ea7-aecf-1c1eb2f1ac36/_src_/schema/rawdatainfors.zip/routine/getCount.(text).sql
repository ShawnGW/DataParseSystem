CREATE PROCEDURE getCount(IN status_f TEXT, OUT sum INT)
  begin
select count(*) into sum from vtcomputers where status = status_f;
end;
