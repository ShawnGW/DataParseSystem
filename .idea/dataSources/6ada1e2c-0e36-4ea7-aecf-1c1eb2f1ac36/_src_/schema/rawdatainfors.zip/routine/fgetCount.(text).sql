CREATE FUNCTION fgetCount(stat TEXT)
  RETURNS VARCHAR(1000)
  begin
	return(select mac_address from vtcomputers where status =stat);
end;
